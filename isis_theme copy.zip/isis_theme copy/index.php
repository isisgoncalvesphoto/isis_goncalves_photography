<?php get_header () ; ?>

<?php get_sidebar () ; ?>

<main class="index-portfolio">
        <section class="container-fluid index-carousel-container p-0">
            <div class="bg-white"></div>
            <div class="index-carousel">
                <div class="slide d-flex justify-content-center">
                    <img src="images/LIFESTYLE/000008.JPG">
                </div>
                <div class="slide d-flex justify-content-center">
                    <img src="images/PORTRAITS/000009.jpg">
                </div>
                <div class="slide d-flex justify-content-center">
                    <img src="images/WEDDINGS/AA_24-10.jpg">
                </div>
            </div>
            <div class="fading"></div>  
            <div class="elements-hero abs container-fluid">
                <div class="main-title logo animate-me">
                    <h1>ISIS <br>GONÇALVES</h1>
                </div>
                <div class="container-fluid themes py-5">
                    <div class="row d-flex align-items-center justify-content-center">
                        <div class="col-md-8 col-sm-10 col-12 menu-main animate-me">
                            <div class="d-flex justify-content-around align-items-center p-md-2">
                                <!-- <button class="arrow d-flex justify-content-center clean hover">
                                    <img src="images/arr_l_w.svg">
                                </button> -->
                                <a class="hover clean fix-width-menu" href="editorial_gallery.html">
                                    <h3>editorial</h3>
                                </a>
                                <div class="d-flex pt-1">
                                    <div class="dot"></div>
                                </div>
                                <a class="hover clean fix-width-menu" href="lifestyle_gallery.html">
                                    <h3>lifestyle</h3>
                                </a>
                                <div class="d-flex pt-1">
                                    <div class="dot"></div>
                                </div>
                                <a class="hover clean fix-width-menu" href="wedding_gallery.html">
                                    <h3>wedding</h3>
                                </a>
                                <!-- <button class="arrow d-flex justify-content-center clean hover">
                                    <img src="images/arr_r_w.svg">
                                </button> -->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="animate-me">
                    <h3>photography</h3>
                </div>
            </div>
        </section>  

        <section class="about-container container-fluid px-0">
            <div class="text-container animate-me">
                <div class="text-margin">
                    <div>
                        <h4 class="pb-xxl-3 pb-3">
                            I believe I was not gifted with the power of words, but that realisation is what
                            drew me to photography in the first place, especially film photography.
                        </h4>
                    </div>
                    <div>
                        <p>
                            I create through capturing not just what looks beautiful, but everything that 
                            evokes some kind of emotion within me. I also love to get to know the people I 
                            photograph. Once we establish a connection, everything flows much more naturally.
                        </p>
                        <p>
                            In recent years, I’ve primarily focused my work on weddings, portraits, and 
                            editorial shoots. However, if you’re looking for a different type of photography,
                                please feel free to reach out to me.
                        </p>
                        <p>
                            When it comes to weddings, you can count on me to capture your special day in the
                                best way possible, staying true to the emotions of the event and providing you 
                                with a stunning gallery. You can also expect my full support and guidance to help 
                                smooth out the day. If you consider yourselves a warm, loving, modern couple, I 
                                believe we will get along very well.
                        </p>
                        <p class="mb-0">With love,</p>
                        <p class="mb-0 bng">
                            ISIS

                        </p>
                    </div>
                </div>
            </div>
            <div class="img-container">
                <div class="img-box-1">
                    <img src="images/ME/1-3.jpg">
                </div>
                <div class="carousel-box-1 animate-me">
                    <div class="about-carousel">
                        <div class="slide d-flex justify-content-center">
                            <img src="images/WEDDINGS/AA_24-2.jpg">
                        </div>
                        <div class="slide d-flex justify-content-center">
                            <img src="images/PORTRAITS/0810-19.jpg">
                        </div>
                        <div class="slide d-flex justify-content-center">
                            <img src="images/WEDDINGS/rnreedit-37.jpg">
                        </div>
                    </div>
                </div>
                <div class="carousel-box-2 animate-me">
                    <div class="about-carousel">
                        <div class="slide d-flex justify-content-center">
                            <img src="images/LIFESTYLE/000017-2.jpg">
                        </div>
                        <div class="slide d-flex justify-content-center">
                            <img src="images/PORTRAITS/bb2.jpg">
                        </div>
                        <div class="slide d-flex justify-content-center">
                            <img src="images/WEDDINGS/IP-54.jpg">
                        </div>
                    </div>
                </div>
                <div class="carousel-box-3 animate-me">
                    <div class="about-carousel">
                        <div class="slide d-flex justify-content-center">
                            <img src="images/PORTRAITS/0815400-39.jpg">
                        </div>
                        <div class="slide d-flex justify-content-center">
                            <img src="images/PORTRAITS/alice-40.jpg">
                        </div>
                        <div class="slide d-flex justify-content-center">
                            <img src="images/WEDDINGS/AA_24-34.jpg">
                        </div>
                    </div>
                </div>
            </div>
            <div class="title-container animate-me" style="mix-blend-mode: exclusion;">
                <div class="segment-title pe-3">
                    <h2 class="px-3">ABOUT</h2>
                </div>
            </div>
        </section>
        <section class="testimonials-container container-fluid px-0">
            <div class="title-container animate-me">
                <div class="segment-title pe-3">
                    <h2 class="px-3">TESTIMONIALS</h2>
                    <div class="button-carousel"></div>
                </div>
            </div>
            <div class="testimonials-carousel px-2 px-sm-4 animate-me">
                <div class="slide d-flex">
                    <div class="testimonial-gradient d-lg-none"></div>
                    <div class="testimonial-photo-container d-flex">
                        <img src="images/WEDDINGS/AA_24-10.jpg">
                    </div>
                    <div class="testimonial-text-container px-4 px-sm-0">
                        <div class="testimonials-text">
                            <h4 class="mb-0">
                                “(…) We really loved the gallery! Isis did a stunning work. She is amazing and was born for this, indeed!”
                            </h4>
                            <p class="mb-0 mt-3 bng">
                                -S & R
                            </p>
                        </div>
                    </div>
                </div>
                <div class="slide d-flex">
                    <div class="testimonial-gradient d-lg-none"></div>
                    <div class="testimonial-photo-container d-flex">
                        <img src="images/WEDDINGS/wedm-1.jpg">
                    </div>
                    <div class="testimonial-text-container px-4 px-sm-0">
                        <div class="testimonials-text">
                            <h4 class="mb-0">
                                “(…)We just saw the photos, and everything looks marvelous! Thank you so much! 
                                Our wedding was captured beautifully! We will definitely contact Isis again in the 
                                future and recommend her whenever someone needs photography services.”
                            </h4>
                            <p class="mb-0 mt-3 bng">
                                -S & M
                            </p>
                        </div>
                    </div>
                </div>
                <div class="slide d-flex">
                    <div class="testimonial-gradient d-lg-none"></div>
                    <div class="testimonial-photo-container d-flex">
                        <img src="images/WEDDINGS/IP-9.jpg">
                    </div>
                    <div class="testimonial-text-container px-4 px-sm-0">
                        <div class="testimonials-text">
                            <h4 class="mb-3">
                                “Isis is incredible. She is exceptionally talented and professional, with a remarkable
                                ability to pay attention to detail. We hired her as our wedding photographer, and the 
                                results were nothing short of perfect. 
                            </h4>
                            <p class="mt-3">
                                (...) She understood our wishes, helped keep us 
                                calm, and transformed what could have been a tedious experience of taking 1,000 
                                photographs into something smooth and enjoyable. The way she captured our special day 
                                was outstanding. We wholeheartedly recommend her work to anyone looking to hire a rising
                                star in photography!”
                            </p>
                            <p class="mb-0 mt-3 bng">
                                -E & C
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- <div class="button-container">
                <div class="button-carousel"></div>
            </div> -->
        </section>
        <section class="contact-container">
            <div class="text-container animate-me">
                <div class="text-margin">
                    <div>
                        <h4 class="pb-xxl-3 pb-3">
                            Looking for the right person to photograph your wedding?
                        </h4>
                    </div>
                    <div>
                        <p>
                            I create through capturing not just what looks beautiful, but everything that 
                            evokes some kind of emotion within me. I also love to get to know the people I 
                            photograph. Once we establish a connection, everything flows much more naturally.
                        </p>
                        <!-- <p>
                            In recent years, I’ve primarily focused my work on weddings, portraits, and 
                            editorial shoots. However, if you’re looking for a different type of photography,
                                please feel free to reach out to me.
                        </p>
                        <p>
                            When it comes to weddings, you can count on me to capture your special day in the
                                best way possible, staying true to the emotions of the event and providing you 
                                with a stunning gallery. You can also expect my full support and guidance to help 
                                smooth out the day. If you consider yourselves a warm, loving, modern couple, I 
                                believe we will get along very well.
                        </p> -->
                        <p class="mb-0">With love,</p>
                        <p class="mb-0 bng">
                            ISIS
                        </p>
                    </div>
                </div>
            </div>
            <div class="form-container animate-me">
                <div class="forms px-2 px-sm-4 py-4">
                    <form id="contact-form">
                        <h3 class="mb-3">Let's start with your name</h3>
                        <input class="mb-5" type="text" name="name" id="client-name" placeholder="Your Name" required />
                      
                        <h4 class="mb-3">What kind of session are you looking for?</h4>
                        <div id="service-selection" class="d-flex justify-content-center flex-wrap">
                          <button class="service-btn" type="button" data-service="wedding">Wedding</button>
                          <button class="service-btn" type="button" data-service="photoshoot">Photoshoot</button>
                          <button class="service-btn" type="button" data-service="editorial">Editorial</button>
                          <button class="service-btn" type="button" data-service="baptism">Baptism</button>
                          <button class="service-btn" type="button" data-service="other">Other</button>
                        </div>
                      
                        <!-- Wedding form section -->
                        <div id="wedding-form-fields" class="service-form">
                          <h4 class="mb-3">Wedding Details:</h4>
                          <input class="mb-3" type="text" name="partner_name" id="partner-name" placeholder="Your Partner's Name" required />
                          <input class="mb-3" type="text" name="location" placeholder="Wedding Location"/>
                          <div class="s-input d-flex justify-content-between">
                              <input class="mb-3" type="date" name="wedding_date" placeholder="Wedding Date"/>
                              <input class="mb-3" type="number" name="number_guests" placeholder="Estimated Number of Guests"/>
                          </div>
                          <textarea class="mb-5" name="message" placeholder="More about you and your special day..."></textarea>
                          <h4 class="mb-3">Fancy some analog photos?</h4>
                          <div id="analog-selection" class="d-flex justify-content-center flex-wrap mb-5">
                            <button class="analog-btn" type="button" data-value="yes-analog">Yes</button>
                            <button class="analog-btn" type="button" data-value="no-analog">No</button>
                            <input type="hidden" name="analog_choice" id="analog-choice" required>
                          </div>
                          <h4 class="mb-3">Your Contact Information:</h4>
                          <div class="s-input d-flex justify-content-between">
                            <input class="mb-3" type="text" name="email" placeholder="Email Address"/>
                            <input class="mb-3" type="text" name="phone" placeholder="Phone Number"/>
                        </div>
                        <textarea class="mb-5" name="socials" placeholder="Feel free to share your socials!"></textarea>
                        <h4 class="mb-3">How did you find about me?</h4>
                        <div id="about-me-selection" class="d-flex justify-content-center flex-wrap mb-5">
                            <button class="about-me-btn" type="button" data-value="instagram">Instagram</button>
                            <button class="about-me-btn" type="button" data-value="facebook">Facebook</button>
                            <button class="about-me-btn" type="button" data-value="google">Google</button>
                            <button class="about-me-btn" type="button" data-value="reference">Reference</button>
                            <button class="about-me-btn" type="button" data-value="casamentos-pt">Casamentos.pt</button>
                            <button class="about-me-btn" type="button" data-value="other">Other</button>
                            <input type="hidden" name="about_me_choice" id="about-me-choice" required>
                          </div>
                        </div>
                      
                        <!-- Generic event form section -->
                        <div id="generic-form-fields" class="service-form">
                          <h4 class="mb-3">Service Details</h4>
                          <div class="s-input d-flex justify-content-between">
                            <input class="mb-3" type="date" name="service_date" placeholder="Date"/>
                            <input class="mb-3" type="text" name="location" placeholder="Location"/>
                          </div>
                          <textarea class="mb-5" name="message" placeholder="More about the service..." required></textarea>
                          <h4 class="mb-3">Your Contact Information:</h4>
                          <div class="s-input d-flex justify-content-between">
                            <input class="mb-5" type="text" name="email" placeholder="Your Email Address"/>
                            <input class="mb-5" type="text" name="phone" placeholder="Your Phone Number"/>
                        </div>
                        <h4 class="mb-3">How did you find about me?</h4>
                        <div id="about-me-selection" class="d-flex justify-content-center flex-wrap mb-5">
                            <button class="about-me-btn" type="button" data-value="instagram">Instagram</button>
                            <button class="about-me-btn" type="button" data-value="facebook">Facebook</button>
                            <button class="about-me-btn" type="button" data-value="google">Google</button>
                            <button class="about-me-btn" type="button" data-value="reference">Reference</button>
                            <button class="about-me-btn" type="button" data-value="casamentos-pt">Casamentos.pt</button>
                            <button class="about-me-btn" type="button" data-value="other">Other</button>
                            <input type="hidden" name="about_me_choice" id="about-me-choice" required>
                          </div>
                        </div>
                      
                        <!-- Submit button (hidden until a service is selected) -->
                        <div id="submit-btn" class="d-flex justify-content-center">
                            <button type="submit">Send</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="title-container animate-me">
                <div class="segment-title pe-3">
                    <h2 class="px-3">CONTACT</h2>
                </div>
            </div>
        </section>
        <section class="instagram-container">
            <div class="insta-sum">
                <div class="insta-carousel animate-me">
                    <div class="slide">
                        <img src="images/LIFESTYLE/000017-2.jpg" alt="Instagram photo 1">
                    </div>
                    <div class="slide">
                        <img src="images/PORTRAITS/sal-33.jpg" alt="Instagram photo 2">
                    </div>
                    <div class="slide">
                        <img src="images/WEDDINGS/rnreedit-37.jpg" alt="Instagram photo 3">
                    </div>
                    <div class="slide">
                        <img src="images/LIFESTYLE/000017-2.jpg" alt="Instagram photo 4">
                    </div>
                    <div class="slide">
                        <img src="images/PORTRAITS/sal-33.jpg" alt="Instagram photo 5">
                    </div>
                    <div class="slide">
                        <img src="images/WEDDINGS/rnreedit-37.jpg" alt="Instagram photo 6">
                    </div>
                </div>
                <div class="follow-container d-flex justify-content-center">
                    <div class="follow">
                        <a class="hover" href="https://www.instagram.com/isistencial/" target="_blank">
                            <h3>
                                follow my work
                            </h3>
                        </a>
                    </div>
                </div>
            </div>
            <div class="title-container animate-me w-100">
                <div class="segment-title pe-3">
                    <h2 class="px-3">INSTAGRAM</h2>
                </div>
            </div>
          </section>
    </main>

<?php get_footer () ; ?>