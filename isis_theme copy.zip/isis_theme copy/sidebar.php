<div class="expand full-menu d-flex justify-content-around align-items-center flex-column">
        <div class="d-md-none d-flex flex-column justify-content-center align-items-center pt-5">
            <h2>GALLERIES</h2>
            <a href="editorial_gallery.html">editorial</a>
            <a href="lifestyle_gallery_gallery.html">lifestyle</a>
            <a href="wedding_gallery.html_gallery.html">wedding</a>
        </div>
        <div class="d-flex justify-content-center flex-column align-items-center pb-5">
            <h2 class="d-md-none">OTHER</h2>
            <button class="hover scroll-about">about</button>
            <button class="hover scroll-testimonials">testimonials</button>
            <button class="hover scroll-contact">contact</button>
            <button class="hover scroll-instagram">instagram</button>
        </div>
        <!-- <button>X</button> -->
    </div>