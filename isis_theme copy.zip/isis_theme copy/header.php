<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Home | Isis Gonçalves Photography</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="slick.css"/>
  <link rel="stylesheet" type="text/css" href="slick-theme.css"/>
  <link rel="stylesheet" href="css/styles_isis.css">
  
  <meta name="description" content="">

  <meta property="og:title" content="">
  <meta property="og:type" content="">
  <meta property="og:url" content="">
  <meta property="og:image" content="">

  <link rel="icon" href="favicon.ico" sizes="any">
  <link rel="icon" href="favicon-32x32.png" type="image/svg+xml">
  <link rel="apple-touch-icon" href="favicon-16x16.png">

  <link rel="manifest" href="site.webmanifest">
  <meta name="theme-color" content="#fafafa">
</head>
<body class="expand">
    <header>
        <div class="container-fluid p-1 p-sm-3 header-container">
            <div class="row d-flex align-items-center header-content">
                <a class="col-5 col-sm-4 col-md-2 logo clean d-flex justify-content-center" href="index.html">
                    <h1>ISIS <br> GONÇALVES</h1>
                </a>
                <div class="col-8 menu-home">
                    <div class="d-flex justify-content-around align-items-center header-border p-2">
                        <!-- <button class="arrow d-flex justify-content-center clean hover">
                            <img src="images/arr_l.svg">
                        </button> -->
                        <a class="hover clean fix-width-menu" href="editorial_gallery.html">
                            <h3>editorial</h3>
                        </a>
                        <div class="d-flex pt-1">
                            <div class="dot"></div>
                        </div>
                        <a class="hover clean fix-width-menu" href="lifestyle_gallery.html">
                            <h3>lifestyle</h3>
                        </a>
                        <div class="d-flex pt-1">
                            <div class="dot"></div>
                        </div>
                        <a class="hover clean fix-width-menu" href="wedding_gallery.html">
                            <h3>wedding</h3>
                        </a>
                        <!-- <button class="arrow d-flex justify-content-center clean hover">
                            <img src="images/arr_r.svg">
                        </button> -->
                    </div>
                </div>
                <!-- <div class="col-8 menu-home">
                    <div class="d-flex justify-content-around align-items-center header-border p-2">
                        <button class="arrow d-flex justify-content-center clean hover">
                            <img src="images/arr_l.svg">
                        </button>
                        <a class="hover clean" href="editorial.html">
                            <h3>editorial</h3>
                        </a>
                        <div class="d-flex pt-1">
                            <div class="dot"></div>
                        </div>
                        <a class="hover clean" href="lifestyle.html">
                            <h3>lifestyle</h3>
                        </a>
                        <div class="d-flex pt-1">
                            <div class="dot"></div>
                        </div>
                        <a class="hover clean" href="wedding.html">
                            <h3>wedding</h3>
                        </a>
                        <button class="arrow d-flex justify-content-center clean hover">
                            <img src="images/arr_r.svg">
                        </button>
                    </div>
                </div> -->
                <button class="offset-3 offset-sm-6 offset-md-0 col-4 col-sm-2 col-xs-3 hover menu clean d-flex justify-content-end justify-content-sm-center">
                    <h3 class="word-menu expand">menu</h3>
                    <h3 class="x-menu expand pe-3 pe-sm-0">X</h3>   
                </button>
            </div>
        </div>
    </header>