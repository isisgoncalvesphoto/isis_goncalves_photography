<footer class="d-flex align-items-center px-1 container-fluid w-100 justify-content-center">
        <div class="d-flex row w-100">
            <div class="d-flex col-12 col-sm-7 col-md-5 col-lg-4 justify-content-around align-items-center">
                <button class="hover scroll-about">
                    <h3>about</h3>
                </button>
                <button class="hover scroll-testimonials">
                    <h3>testimonials</h3>
                </button>
                <button class="hover scroll-contact">
                    <h3>contact</h3>
                </button>
            </div>
            <div class="d-none d-lg-block col-lg-4">
                <!-- <button class="back hover">
                    <img src="images/seta_thin.svg">
                </button> -->
            </div>
            <div class="d-none d-sm-flex col-5 col-md-7 col-lg-4 pt-2 justify-content-end">
                <a class="logo clean" href="index.html">
                    <h1>ISIS <br> GONÇALVES</h1>
                </a>
            </div>
        </div>
    </footer>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" 
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" 
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script type="text/javascript" src="slick.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" 
    integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" 
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="js/portfolio_java.js"></script>
    
</body>
</html>